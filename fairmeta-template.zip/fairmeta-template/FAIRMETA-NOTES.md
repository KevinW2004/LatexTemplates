# fairmeta 模板使用说明

**模板来源**：Meta FAIR preprint 风格（*Dive into Claude Code*, Liu et al., 2026）  
**本地存放**：`fairmeta-template/`  
**主论文入口**：`CausalClaw-Paper.tex`（已套用此模板）

---

## 快速开始

### 文档类选项

```tex
% 单列（默认，适合 preprint / arXiv）
\documentclass[]{style}

% 双列（适合会议投稿格式）
\documentclass[twocolumn]{style}

% 启用 Meta Optimistic 字体（仅 pdfLaTeX，需要 assets/ 文件夹）
\documentclass[optimistic]{style}

% 使用 natbib 而非 biblatex（不推荐，仅兼容旧项目）
\documentclass[natbib]{style}
```

### 编译方式

推荐 **XeLaTeX + biber**（与项目现有配置一致）：

```bash
latexmk -xelatex main.tex
# biber 会被 latexmk 自动调用
```

`.vscode/settings.json` 中已配置 `latexmk -xelatex` 自动编译。

---

## 标题框命令（在 `\begin{document}` 之前填写）

这是 fairmeta 最具特色的设计——标题、作者、摘要都放在一个浅蓝色圆角框里：

```tex
\title{论文标题}

% 作者：用上标数字对应机构
\author[1]{作者甲}
\author[1,2]{作者乙}
\author[1,\dagger]{通讯作者}

% 机构
\affiliation[1]{上海人工智能实验室}
\affiliation[2]{上海交通大学}

% 贡献说明（可选）
\contribution[\dagger]{Corresponding author}

% 通讯信息（显示在标题框底部）
\correspondence{作者甲 (\email{author@example.com})}

% 摘要——注意是命令形式，不是 environment
\abstract{
  摘要内容……
}
```

> **注意**：`\abstract{...}` 是命令，不是 `\begin{abstract}...\end{abstract}` 环境。

---

## 参考文献（biblatex + biber）

本模板默认使用 **biblatex**，不需要 `\bibliographystyle`。

### 基本流程

```tex
% 在导言区（\begin{document} 之前）指定 bib 文件：
\addbibresource{references.bib}

% 正文中引用：
\citep{key}        % 括号式：(Author, 2024)
\citet{key}        % 行内式：Author (2024)
\cite{key}         % 同 \citet
\parencite{key}    % 同 \citep（biblatex 原生命令）
\textcite{key}     % 同 \citet（biblatex 原生命令）

% 文档末尾输出参考文献列表：
\printbibliography
```

### 常用 biblatex 选项（在 style.cls 里已预配置）

| 选项 | 当前值 | 说明 |
|------|--------|------|
| `style` | `authoryear-comp` | 作者-年份格式 |
| `natbib` | `true` | 兼容 `\citep`/`\citet` 语法 |
| `sorting` | `nyt` | 按姓名/年份/标题排序 |
| `maxcitenames` | `2` | 正文中最多显示 2 个作者 |

---

## 图片

```tex
% 推荐在导言区设置图片搜索路径：
\graphicspath{{figures/}}

% 插入图片：
\begin{figure}[t]
  \centering
  \includegraphics[width=\linewidth]{your_figure}
  \caption{图注。}
  \label{fig:example}
\end{figure}

% 引用图：
\figref{fig:example}  % → "Fig. 1"（暗红色可点击链接）
```

---

## 常用引用宏（`resources/preamble.tex` 中定义）

| 命令 | 输出 |
|------|------|
| `\figref{fig:xxx}` | Fig. N（暗红色） |
| `\tabref{tab:xxx}` | Tab. N |
| `\secref{sec:xxx}` | Sec. N |
| `\algref{alg:xxx}` | Alg. N |
| `\appref{app:xxx}` | App. N |
| `\eqref{eq:xxx}` | Eq. N |

---

## 注释与 TODO 命令

```tex
\TODO{待完成的内容}          % 红色粗体 [TODO: ...]
\todo{草稿文字}              % 红色文字
\red{高亮文字}               % 红色

% 提交前关闭 TODO 显示（在 preamble.tex 取消注释）：
% \renewcommand{\TODO}[1]{}
% \renewcommand{\todo}[1]{#1}
```

---

## 字体说明

### 默认（推荐）

`style.cls` 默认不启用 Optimistic 字体，使用系统默认无衬线字体（Helvetica / Latin Modern Sans）。适合 XeLaTeX 和 pdfLaTeX。

### 启用 Meta Optimistic 字体（pdfLaTeX 专用）

```tex
% 需要 assets/ 文件夹中有 Optimistic.ttf 和 optimistic.tfm
\documentclass[optimistic]{style}
```

> **⚠️ 注意**：`optimistic` 选项仅在 **pdfLaTeX** 下有效。
> 在 **XeLaTeX** 下启用 Optimistic 字体，改用 fontspec：
> ```tex
> \usepackage{fontspec}
> \setsansfont{Optimistic}[Path=assets/, Extension=.ttf]
> ```

---

## 文件结构

```
fairmeta-template/
├── style.cls                  # 模板核心类文件（不要修改）
├── main.tex                   # 主文件入口（复制后重命名使用）
├── references.bib             # 参考文献（示例）
├── assets/
│   ├── Optimistic.ttf         # Meta 定制字体（可选）
│   ├── optimistic.tfm         # 字体度量文件（可选）
│   └── plainnat.bst           # natbib 样式文件（natbib 模式下使用）
├── resources/
│   ├── preamble.tex           # 共享宏定义和包加载
│   └── sections.tex           # \input{} 路由文件
├── sections/
│   ├── introduction.tex
│   ├── related_work.tex
│   ├── method.tex
│   ├── experiments.tex
│   ├── conclusion.tex
│   └── appendix.tex
└── figures/                   # 图片目录
```

---

## 与 ElegantPaper 对比

| 特性 | ElegantPaper | fairmeta |
|------|-------------|---------|
| 文献工具 | biblatex + biber | biblatex + biber（同） |
| 标题样式 | 普通 `\maketitle` | tcolorbox 浅蓝圆角框 ✨ |
| 作者格式 | `\author{名字 \\ \email{...}}` | `\author[编号]{名字}` |
| 摘要 | `abstract` environment | `\abstract{...}` 命令 |
| 章节字体 | 衬线 + 彩色 | 无衬线粗体（现代简洁） |
| 单/双列 | 单列为主 | 两者均支持 |
| 附录 | `\appendix` | `\beginappendix` |

---

## 注意事项

- `style.cls` 是模板核心，不要随意修改。如有自定义需求，在 `resources/preamble.tex` 中覆盖。
- 使用 `\abstract{...}` 时，内容中的段落用 `\par` 或空行分隔均可。
- `\correspondence{...}` 内容会显示在标题框底部的 metadata 区域。
- 附录调用 `\beginappendix` 而不是 `\appendix`（后者已被模板重定义）。
