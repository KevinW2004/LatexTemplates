# Place your paper figures here.
#
# Supported formats: PDF (recommended for vector graphics), PNG, JPG
# Reference in LaTeX: \includegraphics[width=\linewidth]{figures/your_figure}
# Or set globally in main.tex: \graphicspath{{figures/}}
