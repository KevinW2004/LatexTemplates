# ElegantPaper 使用要点（CausalClaw 项目精简版）

本项目保留 `elegantpaper.cls` 作为本地论文模板类，主论文文件为 `CausalClaw-Paper.tex`。

## 推荐写法

```tex
\documentclass[11pt,en,a4paper]{elegantpaper}
\usepackage[UTF8,scheme=plain]{ctex} % 英文论文中临时写中文 TODO 时需要
\addbibresource[location=local]{reference.bib}
```

- 正文按英文论文写；中文只建议用于临时注释/TODO。
- 因为需要中文 TODO，继续用 XeLaTeX 编译。
- `.vscode/settings.json` 已配置 LaTeX Workshop 使用 `latexmk -xelatex` 自动实时编译。

## 常用模板命令

- `\email{mail@example.com}`：邮箱链接。
- `\keywords{...}`：摘要末尾关键词。
- `\figref{fig:xxx}`：生成 “Figure n”。
- `\tabref{tab:xxx}`：生成 “Table n”。

## 参考文献

- 文献统一放在 `reference.bib`。
- 正文用 `\cite{key}` 或 `\parencite{key}` 引用。
- ElegantPaper 默认使用 `biblatex` + `biber`；`latexmk` 通常会自动处理多轮编译。

## 图片与附录

- 模板默认搜索图片目录：`image/`、`figure/`、`fig/`、`img/`。
- 本项目建议新图放 `figures/` 或 `images/`，如果需要可在主 tex 里补充：

```tex
\graphicspath{{figures/}{images/}}
```

## 注意事项

- `elegantpaper.cls` 是模板核心文件，不能删除。
- 如果只写英文且完全不需要中文 TODO，可以移除 `ctex` 并改用纯英文 XeLaTeX/pdfLaTeX 流程。
- `math=newtx` 可能引入数学字体冲突；当前建议先使用默认数学字体。
- 版本号可不写 `\version{...}`；不需要日期时用 `\date{}`。
