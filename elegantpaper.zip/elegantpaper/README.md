# ElegantPaper 模板存档

存档时间：2026-07-09

本目录为 **ElegantPaper** LaTeX 模板的存档，包含 CausalClaw 论文最初使用 ElegantPaper 时的所有相关文件。

## 文件说明

| 文件 | 说明 |
|------|------|
| `elegantpaper.cls` | ElegantPaper 模板类文件（核心） |
| `ELEGANTPAPER-NOTES.md` | 模板使用要点，包含推荐写法、常用命令、注意事项 |
| `CausalClaw-Paper-elegantpaper.tex` | CausalClaw 论文在 ElegantPaper 模板下的最终版本（只读存档） |

## 快速恢复使用

如需在新项目中使用 ElegantPaper：

1. 将 `elegantpaper.cls` 复制到项目根目录
2. 主文件首行使用：
   ```tex
   \documentclass[11pt,en,a4paper]{elegantpaper}
   ```
3. 参考 `ELEGANTPAPER-NOTES.md` 中的使用说明

## 编译方式

ElegantPaper 推荐使用 **XeLaTeX + biber**：
```bash
latexmk -xelatex main.tex
```

`.vscode/settings.json` 中的配置（已在存档前应用）：
```json
{
  "latex-workshop.latex.recipe.default": "latexmk (xelatex)"
}
```

## 说明

CausalClaw 论文已迁移到新模板（fairmeta 风格）。本目录仅作存档参考，不再维护。
新论文文件为项目根目录下的 `CausalClaw-Paper.tex`。
